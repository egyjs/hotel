<?php
    logout();
    to('/');

//
