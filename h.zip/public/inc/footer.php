<?php
/**
 * Created by PhpStorm.
 * User: el3zahaby
 * Date: 12/11/18
 * Time: 11:23 PM
 */
?>

<footer class="shadow p-3 mb-5 bg-white rounded container text-center">
    <h5>جميع الحقوق محفوظة &copy; <?= date('Y') ?></h5>
</footer>
</body>